p = pd.Period('2016-07')
p.start_time
p.end_time